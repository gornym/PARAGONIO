// panele (paragon, faktura, kart gwarancyjne)

const tabs = document.querySelectorAll(".przycisk_tab");
const tabsContainer = document.querySelector(".panel-naglowek");
const tabsContent = document.querySelectorAll(".panel_tresc");

tabsContainer.addEventListener("click", function (e) {
  const clicked = e.target.closest(".przycisk_tab");

  if (!clicked) return;

  tabs.forEach((t) => t.classList.remove("przycisk_tab-aktywny"));
  tabsContent.forEach((c) => c.classList.remove("panel_tresc-aktywny"));

  clicked.classList.add("przycisk_tab-aktywny");

  document
    .querySelector(`.panel_tresc-${clicked.dataset.tab}`)
    .classList.add("panel_tresc-aktywny");
});

// dodawanie zdjec
const firebaseConfig = {
  apiKey: "AIzaSyA7ZuB7n_Q8q1zvHYUEoo27yTB3uDxOFLM",
  authDomain: "paragonio-a9d51.firebaseapp.com",
  databaseURL:
    "https://paragonio-a9d51-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "paragonio-a9d51",
  storageBucket: "paragonio-a9d51.appspot.com",
  messagingSenderId: "376554158139",
  appId: "1:376554158139:web:be10cb845338b4eb72841e",
};

firebase.initializeApp(firebaseConfig);

var uploadPercentage = document.querySelector(".uploadPercentage");
var progress = document.querySelector(".progress");
var percentVal;
var fileItem;
var fileName;
var fvName;
var gwName;
var img = document.querySelector(".img");
var categorySelect = document.getElementById("categorySelect");
var dateInput = document.getElementById("dateInput");
var amountInput = document.getElementById("amountInput");
var uploadIcon = document.getElementById("uploadIcon");

function getFile(e) {
  fileItem = e.target.files[0];
  fileName =
    categorySelect.value +
    "/" +
    dateInput.value +
    "_" +
    amountInput.value +
    "_" +
    fileItem.name;
  uploadIcon.src = "img/dodano.png";
}

function uploadImage() {
  let user = firebase.auth().currentUser;
  if (user) {
    let userId = user.uid;
    let storageRef = firebase.storage().ref(userId + "/images/" + fileName);
    let uploadTask = storageRef.put(fileItem);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        console.log(snapshot);
        percentVal = Math.floor(
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        );
        console.log(percentVal);
        uploadPercentage.innerHTML = percentVal + "%";
        progress.style.width = percentVal + "%";
      },
      (error) => {
        console.log("error is", error);
      },
      () => {
        uploadTask.snapshot.ref.getDownloadURL().then((url) => {
          console.log("URL", url);
          alert("Paragon został dodany pomyślnie!");

          var myDiv = document.querySelector(".foldery");

          var image = document.createElement("img");
          image.src = url;

          myDiv.appendChild(image);

          categorySelect.value = "";
          dateInput.value = "";
          amountInput.value = "";
          uploadIcon.src = "img/plus5.png";

          localStorage.setItem("paragonURL", url);
        });
      }
    );
  }
}

var storedURL = localStorage.getItem("paragonURL");

if (storedURL) {
  var myDiv = document.querySelector(".foldery");
  var image = document.createElement("img");
  image.src = storedURL;
  myDiv.appendChild(image);
}

function getFile(e) {
  fileItem = e.target.files[0];
  fvName = dateInput.value + "_" + amountInput.value + "_" + fileItem.name;
  uploadIcon.src = "img/dodano.png";
}

function uploadFaktura() {
  let user = firebase.auth().currentUser;
  if (user) {
    let userId = user.uid;
    let storageRef = firebase.storage().ref(userId + "/faktura/" + fvName);
    let uploadTask = storageRef.put(fileItem);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        console.log(snapshot);
        percentVal = Math.floor(
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        );
        console.log(percentVal);
        uploadPercentage.innerHTML = percentVal + "%";
        progress.style.width = percentVal + "%";
      },
      (error) => {
        console.log("error is", error);
      },
      () => {
        uploadTask.snapshot.ref.getDownloadURL().then((url) => {
          console.log("URL", url);

          alert("Faktura została dodana pomyślnie!");

          dateInput.value = "";
          amountInput.value = "";
          uploadIcon.src = "img/plus5.png";
        });
      }
    );
  }
}

function getFile(e) {
  fileItem = e.target.files[0];
  gwName = dateInput.value + "_" + amountInput.value + "_" + fileItem.name;
  uploadIcon.src = "img/dodano.png";
}

function uploadGwarancja() {
  let user = firebase.auth().currentUser;
  if (user) {
    let userId = user.uid;
    let storageRef = firebase
      .storage()
      .ref(userId + "/karta gwarancyjna/" + gwName);
    let uploadTask = storageRef.put(fileItem);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        console.log(snapshot);
        percentVal = Math.floor(
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        );
        console.log(percentVal);
        uploadPercentage.innerHTML = percentVal + "%";
        progress.style.width = percentVal + "%";
      },
      (error) => {
        console.log("error is", error);
      },
      () => {
        uploadTask.snapshot.ref.getDownloadURL().then((url) => {
          console.log("URL", url);
          alert("Karta gwarancyjna została dodana pomyślnie!");

          dateInput.value = "";
          amountInput.value = "";
          uploadIcon.src = "img/plus5.png";
        });
      }
    );
  }
}

function showimage() {
  var storageRef = firebase.storage().ref();
  var spaceRef = storageRef.child("sweet_gift/vytcdc.png");
  storageRef
    .child("sweet_gift/vytcdc.png")
    .getDownloadURL()
    .then(function (url) {
      var test = url;
      alert(url);
      document.querySelector("img").src = test;
    })
    .catch(function (error) {});
}
// function showDivsForCategories() {
//   let user = firebase.auth().currentUser;
//   if (user) {
//     let userId = user.uid;
//     let storageRef = firebase.storage().ref(userId + "/images/");

//     storageRef
//       .listAll()
//       .then(function (res) {
//         var items = res.items;
//         var categories = [];

//         items.forEach(function (item) {
//           var category = item.name.split("/")[0];
//           categories.push(category);
//         });

//         var divs = document.querySelectorAll(".box");

//         divs.forEach(function (div) {
//           var dataValue = div.getAttribute("data-value");

//           if (categories.includes(dataValue)) {
//             div.style.display = "block";
//           }
//         });
//       })
//       .catch(function (error) {
//         console.log(
//           "Błąd podczas pobierania listy elementów z Firebase Storage:",
//           error
//         );
//       });
//   }
// }
